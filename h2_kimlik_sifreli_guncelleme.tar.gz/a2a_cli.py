#!/usr/bin/env python3
"""
a2a_cli.py — A2A mesh client (CumulusNET)

Kullanım:
  a2a_cli.py send <host> "<görev metni>" [--token X]     → task_id + durum
  a2a_cli.py send-status <host> [--token X]              → makine durumu iste
  a2a_cli.py get <host> <task_id> [--token X]            → sonuç
  a2a_cli.py card <host> [--token X]                     → AgentCard
  a2a_cli.py ping <host> [--token X]                     → sağlık

Host örnekleri: 100.103.44.107 (H3), 100.92.2.47 (H1), 100.76.82.46 (H2)
"""
# pyright: reportOptionalMemberAccess=false
import argparse
import json
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
_CARD_CACHE: dict[str, tuple] = {}
_CARD_TTL = 300
try:
    import agent_identity as AI
    IDENTITY_OK = True
except Exception:
    AI = None
    IDENTITY_OK = False

_IDENT = None


def identity():
    """Yerel kimlik (imza için). Yoksa imzasız gönderilir (eski davranış)."""
    global _IDENT
    if _IDENT is None and IDENTITY_OK:
        try:
            _IDENT = AI.AgentIdentity.load_or_create()
        except Exception:
            return None
    return _IDENT


def peer_card(host: str, port: int = 8643):
    """Karşı tarafın AgentCard'ı (önbellekli). Şifreli gönderim için X25519
    açık anahtarı ve şifreleme desteği buradan alınır."""
    now = time.time()
    key = f"{host}:{port}"
    hit = _CARD_CACHE.get(key)
    if hit and now - hit[1] < _CARD_TTL:
        return hit[0]
    req = urllib.request.Request(f"http://{host}:{port}/.well-known/agent.json")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            card = json.loads(resp.read().decode())
        _CARD_CACHE[key] = (card, now)
        return card
    except Exception:
        return hit[0] if hit else {}


def rpc(host: str, method: str, params: dict, token: str, port: int = 8643,
        sign: bool = True, conv_id: str = "", encrypt: bool = True):
    url = f"http://{host}:{port}/"
    body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params}).encode()
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"})
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    ident = identity() if sign else None
    if ident:
        # Klon şüphesinde kendi kimliğimizle mesaj GÖNDERMEYİZ (fail-closed)
        ident.assert_not_clone()
        card = peer_card(host, port)
        peer_enc = (card.get("capabilities") or {}).get("encryptedRequests")
        peer_x = (card.get("identity") or {}).get("x25519_public", "")
        if encrypt and peer_enc and peer_x:
            # ŞİFRELİ gövde: X25519 ECDH + AES-GCM (PFS) + Ed25519 imza
            peer_aid = (card.get("identity") or {}).get("agent_id", "")
            env = ident.secure_payload(peer_x, body, to_agent=peer_aid)
            env["runtime"] = ident.runtime
            env["machine_label"] = ident.meta.get("machine_label", "")
            body2 = json.dumps({"enc": env}).encode()
            req.data = body2
            req.add_header("X-Agent-Enc", "v1")
            req.add_header("X-Agent-Label", ident.meta.get("machine_label", ""))
            if conv_id:
                req.add_header("X-Conversation-Id", conv_id)
        else:
            # İmzalı ama düz gövde (eski sunucu / şifreleme yok)
            for k, v in ident.sign_request(method, body).items():
                req.add_header(k, v)
            req.add_header("X-Agent-Label", ident.meta.get("machine_label", ""))
            if conv_id:
                req.add_header("X-Conversation-Id", conv_id)
    with urllib.request.urlopen(req, timeout=120) as resp:
        out = json.loads(resp.read().decode())
    # Giden mesajı yerel sohbet defterine işle (karşı tarafın agent_id'si ile)
    peer = ((out.get("result") or {}).get("served_by") or "") if isinstance(out, dict) else ""
    if ident and peer.startswith(("hx-", "oc-")):
        try:
            cid = conv_id or AI.open_conversation("agent", peer, "a2a", identity=ident)
            mid = AI.log_message(cid, "out", body, peer_id=peer,
                                 meta={"method": method, "host": host})
            if isinstance(out, dict):
                out["_local_conversation_id"] = cid
                out["_local_message_id"] = mid
        except Exception:
            pass
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("komut", choices=["send", "send-status", "get", "card", "ping", "stream"])
    ap.add_argument("host")
    ap.add_argument("gorev", nargs="?", default="")
    ap.add_argument("--task-id", default="")
    ap.add_argument("--token", default="")
    ap.add_argument("--port", type=int, default=8643)
    ap.add_argument("--mode", choices=["sync", "async"], default="sync")
    ap.add_argument("--seconds", type=int, default=8)
    ap.add_argument("--no-sign", action="store_true", help="imzasız gönder (eski uyum)")
    ap.add_argument("--conv", default="", help="mevcut sohbet ID'si ile devam et")
    args = ap.parse_args()
    sign = not args.no_sign

    try:
        if args.komut == "send":
            r = rpc(args.host, "task/send", {"payload": {"action": "note", "text": args.gorev},
                                             "mode": args.mode}, args.token, args.port,
                    sign=sign, conv_id=args.conv)
            print(json.dumps(r, ensure_ascii=False, indent=2))
        elif args.komut == "send-status":
            r = rpc(args.host, "task/send", {"payload": {"action": "status"}, "mode": args.mode},
                    args.token, args.port, sign=sign, conv_id=args.conv)
            print(json.dumps(r, ensure_ascii=False, indent=2))
        elif args.komut == "get":
            r = rpc(args.host, "task/get", {"id": args.task_id}, args.token, args.port,
                    sign=sign, conv_id=args.conv)
            print(json.dumps(r, ensure_ascii=False, indent=2))
        elif args.komut == "card":
            req = urllib.request.Request(f"http://{args.host}:{args.port}/.well-known/agent.json")
            with urllib.request.urlopen(req, timeout=30) as resp:
                print(resp.read().decode())
        elif args.komut == "ping":
            req = urllib.request.Request(f"http://{args.host}:{args.port}/health")
            with urllib.request.urlopen(req, timeout=30) as resp:
                print(resp.read().decode())
        elif args.komut == "stream":
            # Canlı SSE akışı: H1 → H3 mesaj akışını dinle
            url = f"http://{args.host}:{args.port}/stream?message={urllib.parse.quote(args.gorev or 'selam')}&seconds={args.seconds}"
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=args.seconds + 10) as resp:
                for line in resp:
                    if line.strip():
                        print(line.decode().strip())
    except Exception as e:
        print(f"HATA: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
